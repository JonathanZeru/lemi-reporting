'use client';
import { useEffect, useState } from "react"
import axios from "axios"
import { format, differenceInMinutes } from "date-fns"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { apiURL } from "@/utils/constants/constants"
import { useParams } from "next/navigation"
import Link from "next/link"
import { useAuthStore } from "@/stores/authStore"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export interface CommonTaskDetailProps {
  id: number
  title: string
  description: string
  startTime: string
  endTime: string
  status: string
  createdByRole: string
  createdById: number
  createdByHiwasId: number | null
  createdByMDId: number | null
  createdByWeredaId: number | null
  createdByWanaId: number | null
  createdAt: string
  updatedAt: string
  reports: any[] // You might want to define a more specific type for reports
  createdByHiwas: {
    id: number
    firstName: string
    lastName: string
    email: string
    phone: string
    userName: string
    role: string
    isActive: boolean
    mdId: number
    createdAt: string
    updatedAt: string
  } | null
  createdByMD: {
    id: number
    firstName: string
    lastName: string
    email: string
    phone: string
    userName: string
    role: string
    isActive: boolean
    mdId: number
    createdAt: string
    updatedAt: string
  } | null // Define a type for MD if available
  createdByWana: {
    id: number
    firstName: string
    lastName: string
    email: string
    phone: string
    userName: string
    role: string
    isActive: boolean
    mdId: number
    createdAt: string
    updatedAt: string
  } | null // Define a type for Wana if available
  createdByWereda: {
    id: number
    firstName: string
    lastName: string
    email: string
    phone: string
    userName: string
    role: string
    isActive: boolean
    mdId: number
    createdAt: string
    updatedAt: string
  } | null // Define a type for Wereda if available
}

const CommonTaskDetail = () => {
  const { scheduleId } = useParams() as { scheduleId: string }
  const [taskDetail, setTaskDetail] = useState<CommonTaskDetailProps | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  // const { user, accessToken } = useAuthStore()

  useEffect(() => {
    const fetchTaskDetail = async () => {
      try {
        const response = await axios.get<CommonTaskDetailProps>(`${apiURL}api/schedule?scheduleId=${scheduleId}`)
        if (response.data) {
          setTaskDetail(response.data)
        } else {
          setError("No Schedule found")
        }
      } catch (err) {
        setError("Failed to fetch Schedule")
        console.error("Error fetching Schedule:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchTaskDetail()
  }, [scheduleId])

  if (loading) return <div>በመካሄድ ላይ...</div>
  if (error) return <div>ስህተት: {error}</div>
  if (!taskDetail) return <div> ምንም የተግባር ዝርዝር አልተገኘም።</div>

  const taskCreatedAt = new Date(taskDetail.createdAt)
  const taskStartTime = new Date(taskDetail.startTime)
  const timeDifferenceInMinutes = differenceInMinutes(taskStartTime, taskCreatedAt)

  const taskStatus = timeDifferenceInMinutes < 0 ? `Late by ${Math.abs(timeDifferenceInMinutes)} minutes` : "Up to Date"

  return (
    <ScrollArea className="h-[calc(100vh-4rem)] w-full">
      <div className="container mx-auto p-4 space-y-6 print:space-y-4">
        <Card className="print:shadow-none print:border-none">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold">የተግባር ዝርዝሮች</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 print:grid-cols-1">
              <div>
                <h2 className="text-xl font-semibold mb-2">የተግባር ዝርዝሮች</h2>
                <p>
                  <strong>ርዕስ:</strong> {taskDetail.title}
                </p>
                <p>
                  <strong>ዝርዝር መግለጫ:</strong> {taskDetail.description}
                </p>
                <p>
                  <strong>የተመዘገበበት ቦታ:</strong> {format(taskCreatedAt, "PPpp")}
                </p>
                <p>
                  <strong>የመነሻ ጊዜ:</strong> {format(new Date(taskDetail.startTime), "PPpp")}
                </p>
                <p>
                  <strong>የመጨረሻ ጊዜ:</strong> {format(new Date(taskDetail.endTime), "PPpp")}
                </p>
                <p>
                  <strong>ሁኔታ:</strong> <Badge>{taskDetail.status}</Badge>
                </p>
                <p>
                  <strong> የጊዜዉ ሁኔታ:</strong> <Badge>{taskStatus}</Badge>
                </p>
              </div>

              {taskDetail.createdByHiwas && (
                <div>
                  <h2 className="text-xl font-semibold mb-2">የተፈጠረው በ</h2>
                  <p>
                    <strong>ስም:</strong> {taskDetail.createdByHiwas.firstName} {taskDetail.createdByHiwas.lastName}
                  </p>
                  <p>
                    <strong>ኢሜል:</strong> {taskDetail.createdByHiwas.email}
                  </p>
                  <p>
                    <strong>ስልክ:</strong> {taskDetail.createdByHiwas.phone}
                  </p>
                  <p>
                    <strong>ሚና:</strong> {taskDetail.createdByHiwas.role}
                  </p>
                </div>
              )}

              {taskDetail.createdByMD && (
                <div>
                  <h2 className="text-xl font-semibold mb-2">የተፈጠረው በ</h2>
                  <p>
                    <strong>ስም:</strong> {taskDetail.createdByMD.firstName} {taskDetail.createdByMD.lastName}
                  </p>
                  <p>
                    <strong>ኢሜል:</strong> {taskDetail.createdByMD.email}
                  </p>
                  <p>
                    <strong>ስልክ:</strong> {taskDetail.createdByMD.phone}
                  </p>
                  <p>
                    <strong>ሚና:</strong> {taskDetail.createdByMD.role}
                  </p>
                </div>
              )}

              {taskDetail.createdByWana && (
                <div>
                  <h2 className="text-xl font-semibold mb-2">የተፈጠረው በ</h2>
                  <p>
                    <strong>ስም:</strong> {taskDetail.createdByWana.firstName} {taskDetail.createdByWana.lastName}
                  </p>
                  <p>
                    <strong>ኢሜል:</strong> {taskDetail.createdByWana.email}
                  </p>
                  <p>
                    <strong>ስልክ:</strong> {taskDetail.createdByWana.phone}
                  </p>
                  <p>
                    <strong>ሚና:</strong> {taskDetail.createdByWana.role}
                  </p>
                </div>
              )}

              {taskDetail.createdByWereda && (
                <div>
                  <h2 className="text-xl font-semibold mb-2">የተፈጠረው በ</h2>
                  <p>
                    <strong>ስም:</strong> {taskDetail.createdByWereda.firstName} {taskDetail.createdByWereda.lastName}
                  </p>
                  <p>
                    <strong>ኢሜል:</strong> {taskDetail.createdByWereda.email}
                  </p>
                  <p>
                    <strong>ስልክ:</strong> {taskDetail.createdByWereda.phone}
                  </p>
                  <p>
                    <strong>ሚና:</strong> {taskDetail.createdByWereda.role}
                  </p>
                </div>
              )}

              {taskDetail.reports && taskDetail.reports.length > 0 && (
                <div>
                  <h2 className="text-xl font-semibold mb-2">ሪፖርቶች</h2>
                  <p>
                    <strong>የሪፖርቶች ብዛት:</strong> {taskDetail.reports.length}
                  </p>
                  <Link href={`/dashboard/task-reports/${taskDetail.id}`}>
                    <Button className="mt-2">ሪፖርቶችን ይመልከቱ</Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </ScrollArea>
  )
}

export default CommonTaskDetail

